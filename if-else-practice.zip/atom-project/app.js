function positive(){
  alert('This is a positive number...')
}
function nagetive(){
  alert('This is a nagetive number...')
}
function zero(){
  alert('This is zero number...')
}
// ============================
let userInput = prompt("Type your number");

if(userInput >= 1){
  document.write('positive number');
}else if (userInput < 0) {
  document.write('nagetive number');
}else if (userInput == 0) {
  document.write('Zero number');
}else {
  document.write('You enter wrong number');
}
// ============================
