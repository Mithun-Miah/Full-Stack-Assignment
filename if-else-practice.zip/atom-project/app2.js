function voteAgeCheck(){
  let voteUser = prompt("Enter your age...");
  if (voteUser >=18) {
    alert('You are eligible to vote...')
  }else {
    alert('You can not to vote...')
  }
}
// ==================================
function voteAgeCheck2(){
  let voteUser = prompt("Enter your age...");
  if (voteUser >=18) {
    document.write('You are eligible to vote...')
  }else {
    document.write('You can not to vote...')
  }
}
// =============================
function voteAgeCheck3(){
  let voteUser = prompt("Enter your age...");

  if (voteUser >=18) {
    document.getElementById('voteMsg').innerHTML = 'You are eligible to vote...';
  }else {
    document.getElementById('voteMsg').innerHTML = 'You can not to vote...';
  }
}
