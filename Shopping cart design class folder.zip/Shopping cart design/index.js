
// for + button 

var pr_ammount = document.getElementById("pr_ammount");
var total_balance = document.getElementById("total_balance");

var charge = document.getElementById("charge");
var item = document.getElementById("item").style.display="none";

function Increament(count,price,Total_item1){
  var count = document.getElementById(count);

  var price  = document.getElementById(price);
  var Total_item  = document.getElementById(Total_item1);


    if(count.value >=5){
      count.value = 5 ;
      alert("maximum 5 product allow");

    }else{
        count.value++;

        var result = parseFloat(price.innerHTML) + parseFloat(Total_item.innerHTML);
        document.getElementById(Total_item1).innerHTML =result;

    // product ammount 
    
    var total_product_ammount =  parseFloat(pr_ammount.innerHTML) + parseFloat(price.innerHTML);
    document.getElementById("pr_ammount").innerHTML =total_product_ammount
     

    //balance 
    var total =  parseFloat(charge.innerHTML) + total_product_ammount ;
    document.getElementById("total_balance").innerHTML = total;


     if(document.getElementById("total_balance").innerHTML>=400){
        document.getElementById("item").style.display="block";
     }



    }
}

// for minus button
function Decrement(count,price,Total_item1){
    var count = document.getElementById(count);

    var price  = document.getElementById(price);
    var Total_item  = document.getElementById(Total_item1);
    
    if(count.value <1 ){
        count.value = 0 ;
        alert("minimum 1 product allow");
  
      }else{
          count.value--;

          var result =parseFloat(Total_item.innerHTML) - parseFloat(price.innerHTML) ; 
          document.getElementById(Total_item1).innerHTML =result;

          // product ammount
          var total_product_ammount =  parseFloat(pr_ammount.innerHTML) - parseFloat(price.innerHTML);
          document.getElementById("pr_ammount").innerHTML =total_product_ammount
  
        //total balance

        var total =  parseFloat(charge.innerHTML) + total_product_ammount ;
        document.getElementById("total_balance").innerHTML = total;
  
         
        // cond

        if(document.getElementById("pr_ammount").innerHTML==0){
            document.getElementById("total_balance").innerHTML =0;
        }
      }
}