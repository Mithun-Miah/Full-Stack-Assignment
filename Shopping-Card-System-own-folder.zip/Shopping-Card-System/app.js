// global variable declear
var sub_total_p = document.getElementById("sub_total_p");
var grand_total_p = document.getElementById("grand_total_p");
var charge = document.getElementById("charge");
var couponDiv = document.getElementById("couponDiv");

couponDiv.style.display = "none"
// items count increament code start
function increament(){
    var count = document.getElementById("count");
    var unit_price = document.getElementById("unit_price");
    var total_items_price = document.getElementById("total_items_price");

    if (count.value >= 5) {
        count.value = 5;
        alert("Maximum 5 Items Allow");
    }else{
        count.value++;

        var amount_sum = parseFloat(unit_price.innerHTML) + parseFloat(total_items_price.innerHTML);
        document.getElementById("total_items_price").innerHTML = amount_sum.toFixed(2);

        // price add in sub-total section start
        var sub_total_sum = parseFloat(unit_price.innerHTML) + parseFloat(sub_total_p.innerHTML);
        document.getElementById("sub_total_p").innerHTML = sub_total_sum.toFixed(2);
        // price add in sub-total section end

        // price add in grand-total section start
        var grand_total_sum = parseFloat(sub_total_p.innerHTML) + parseFloat(charge.innerHTML);
        document.getElementById("grand_total_p").innerHTML = grand_total_sum.toFixed(2);
        // price add in grand-total section end

        // coupon section hide / show condition start
        if (document.getElementById("grand_total_p").innerHTML >= 400) {
            couponDiv.style.display = "block";
        }else {
            couponDiv.style.display = "none";
        }
        // coupon section hide / show condition end
    }
}
// items count increament code end

// items count decreament code start
function decreament(){
    var count = document.getElementById("count");
    var unit_price = document.getElementById("unit_price");
    var total_items_price = document.getElementById("total_items_price");

    if(count.value < 1){
        count.value = 0;
        alert("Maximum 1 Items Allow");
    }else{
        count.value--;

        var amount_sum = parseFloat(total_items_price.innerHTML) - parseFloat(unit_price.innerHTML);
        document.getElementById("total_items_price").innerHTML = amount_sum.toFixed(2);

        // price add in sub-total section start
        var sub_total_sum = parseFloat(sub_total_p.innerHTML) - parseFloat(unit_price.innerHTML);
        document.getElementById("sub_total_p").innerHTML = sub_total_sum.toFixed(2);
        // price add in sub-total section end

        // price add in grand-total section start
        var grand_total_sum =  parseFloat(charge.innerHTML) + sub_total_sum ;
        document.getElementById("grand_total_p").innerHTML = grand_total_sum.toFixed(2);
        // price add in grand-total section end

        // grand total balance 0 condition
        if (document.getElementById("sub_total_p").innerHTML == 0) {
            document.getElementById("grand_total_p").innerHTML = 0;
        }
    }
    
}
// items count decreament code end