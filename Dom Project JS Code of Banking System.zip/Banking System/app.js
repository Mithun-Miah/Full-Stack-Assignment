var log_btn = document.getElementById("log_btn");
var acc_input = document.getElementById("acc_no");
var pass_input = document.getElementById("pass");
var login_sec = document.getElementById("user_login");
var dash_sec = document.getElementById("user_dashboard");

// password show / hide code start
function checkMark(){
    if(pass_input.type == "password"){
        pass_input.type = "text";
    }else{
        pass_input.type = "password"
    }
}
// password show / hide code end

// user login code start
log_btn.addEventListener('click', function(event){

    event.preventDefault();

    if(acc_input.value == "" || pass_input.value == ""){
        alert("You Can Not Login Without Account and Password...!");
    }else{

        login_sec.style.display = "none";
        dash_sec.style.display = "block";
    }
})
// user login code end

// ======= User Main Dashbord Code Start =========

// deposit section code start
var depo_btn = document.getElementById("depo_btn");

depo_btn.addEventListener('click', function(){
    var depo_input = parseFloat(document.getElementById("depo_in").value);
    var depo_bal = parseFloat(document.getElementById("depo_bal").innerHTML);

    if(depo_input <= 0){
        alert("Please Enter a Valid Amount");
    }else if(depo_input >= 5000){
        alert("You Can Not Deposit More 5000/- In A Day...");
    }
    else{
        var depo_sum = depo_input + depo_bal;
        var depo_add = document.getElementById("depo_bal").innerHTML = depo_sum.toFixed(2);
        // deposit amount add to total balance start
        var total_bal = parseFloat(document.getElementById("total_bal").innerHTML);
        var add_total_bal = depo_input + total_bal;

        document.getElementById("total_bal").innerHTML = add_total_bal.toFixed(2);
        // deposit amount add to total balance end
    }
})

    // withdraw amount add total balance start
var withdraw_btn = document.getElementById("withdraw_btn");

withdraw_btn.addEventListener('click', function(){
    var withdraw_input = parseFloat(document.getElementById("withdraw_in").value);
    var withdraw_bal = parseFloat(document.getElementById("withdraw_bal").innerHTML);
    var total_bal = parseFloat(document.getElementById("total_bal").innerHTML);

    console.log(withdraw_input);

    var withdraw_sum = withdraw_input + withdraw_bal;
    document.getElementById("withdraw_bal").innerHTML = withdraw_sum.toFixed(2);

    if(total_bal <= 500){
        alert("Your balance invalid");
    }else{
        var total_withdraw_bal = total_bal - withdraw_input;
        document.getElementById("total_bal").innerHTML = total_withdraw_bal.toFixed(2);
    }

})
    // withdraw amount add total balance end

// deposit section code end


// ========= User Main Dashbord Code End =========