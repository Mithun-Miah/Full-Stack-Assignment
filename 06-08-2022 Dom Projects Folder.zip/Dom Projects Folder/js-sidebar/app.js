var icon = document.getElementById("sb-icon");
icon.addEventListener('click', function(){
    var sideBar = document.getElementById("side-bar");
    sideBar.classList.toggle("sidebarClose");
});