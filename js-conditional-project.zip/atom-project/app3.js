let ban = document.getElementById('ban').value;
let eng = document.getElementById('eng').value;
let mat = document.getElementById('mat').value;
let sci = document.getElementById('sci').value;
let his = document.getElementById('his').value;

let res_btn = document.getElementById('res-btn');

res_btn.addEventListener('click', function(){
	
	/* if(ban == '' || eng == '' || mat == '' || sci == '' || his == ''){
		document.getElementById('err-msg').innerHTML = '*** Fillup Your All Subject Marks Correctly...';
	} */
	
	let all_marks = parseInt(ban)+parseInt(eng)+parseInt(mat)+parseInt(sci)+parseInt(his);	
	
	
});
	



/* function voteAgeCheck(){
  let voteUser = prompt("Enter your age...");
  if (voteUser >=18) {
    alert('You are eligible to vote...')
  }else {
    alert('You can not to vote...')
  }
}
// ==================================
function voteAgeCheck2(){
  let voteUser = prompt("Enter your age...");
  if (voteUser >=18) {
    document.write('You are eligible to vote...')
  }else {
    document.write('You can not to vote...')
  }
}
// =============================
function voteAgeCheck3(){
  let voteUser = prompt("Enter your age...");

  if (voteUser >=18) {
    document.getElementById('voteMsg').innerHTML = 'You are eligible to vote...';
  }else {
    document.getElementById('voteMsg').innerHTML = 'You can not to vote...';
  }
} */
