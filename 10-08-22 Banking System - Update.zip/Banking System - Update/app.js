// password show / hide code start
function checkMark(){
    if (pass.type == "password") {
        pass.type = "text";
    }else{
        pass.type = "password";
    }
}
// password show / hide code end

// user login code start
var log_btn = document.getElementById("log_btn");

log_btn.addEventListener('click', function(event){
    event.preventDefault();
    
    var acc_no = document.getElementById("acc_no");
    var pass = document.getElementById("pass");

    if (acc_no.value == "" || pass.value == "") {
        alert("Account Number And Password Must be Required !");
    }else{
        var user_login_sec = document.getElementById("user_login");
        var user_dashboard_sec = document.getElementById("user_dashboard");

        user_login_sec.style.display = "none";
        user_dashboard_sec.style.display = "block";
    }
})
// user login code end

// ======= User Main Dashbord Code Start =========

// deposit section code start
var depo_btn = document.getElementById("depo_btn");

depo_btn.addEventListener('click', function(){
    var depo_in = document.getElementById("depo_in").value;
    var depo_bal = document.getElementById("depo_bal").innerHTML;

    if(depo_in == ""){
        alert("Deposit Amount Invalid");
    }else if(depo_in <= 0){
        alert("Nagetive Amount Not Accepted");
    }else if(depo_in <= 499){
        alert("Minimum Deposit Amount 500/- for Each Time");
    }else{
        var depo_sum = parseFloat(depo_in) + parseFloat(depo_bal);
        document.getElementById("depo_bal").innerHTML = depo_sum.toFixed(2);
        // deposit amount add to total balance start
        var total_bal = document.getElementById("total_bal").innerHTML;
        var total_bal_sum = parseFloat(depo_in) + parseFloat(total_bal);
        document.getElementById("total_bal").innerHTML = total_bal_sum.toFixed(2);
        // deposit amount add to total balance end
    }

})
// deposit section code end

// withdraw section code start
var withdraw_btn = document.getElementById("withdraw_btn");

withdraw_btn.addEventListener('click', function(){
    var withdraw_in = document.getElementById("withdraw_in").value;
    var withdraw_bal = document.getElementById("withdraw_bal").innerHTML;

    if (withdraw_in == "") {
        alert("Withdraw Amount Invalid");
    }else if(withdraw_in <= 0){
        alert("Nagetive Withdraw Amount Not Accepted");
    }else if(withdraw_in <= 499){
        alert("Minimum Withdraw Amount 500/- for Each Time");
    }else{
        var withdraw_sum = parseFloat(withdraw_in) + parseFloat(withdraw_bal);
        document.getElementById("withdraw_bal").innerHTML = withdraw_sum.toFixed(2);

        // withdraw amount add to total balance start
        var total_bal2 = document.getElementById("total_bal").innerHTML;
        
        if(total_bal2 <= 500){
            alert("You do not have sufficient balance");
        }else{
            var total_bal_sum2 = parseFloat(total_bal2) - parseFloat(withdraw_in);
            document.getElementById("total_bal").innerHTML = total_bal_sum2.toFixed(2);
        }
        // withdraw amount add to total balance end
    }
})
// withdraw section code end

// logout / exit code start
var log_out = document.getElementById("log_out");

log_out.addEventListener('click', function(event2){
    event2.preventDefault();

    var user_login_sec2 = document.getElementById("user_login");
    var user_dashboard_sec2 = document.getElementById("user_dashboard");
    var acc_no = document.getElementById("acc_no");
    var pass = document.getElementById("pass");

    user_login_sec2.style.display = "block";
    user_dashboard_sec2.style.display = "none";

    acc_no.value = "";
    pass.value = "";
})
// logout / exit code end


// ========= User Main Dashbord Code End =========